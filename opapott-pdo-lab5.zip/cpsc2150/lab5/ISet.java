/*
    Olivia Papotto
    Phillip Do
 */
package cpsc2150.lab5;

import java.util.*;

/**
 * ISet represents a set of user inputted values
 *
 * Initialization ensures:
 *      ISet contains a blank list/array and is of size 0
 *      if list, or MAX_SIZE if array
 *
 * Defines:     getSize: Z
 *
 * Constraints: 0 <= ISet.getSize() < MAX_SIZE
 *
 */
public interface ISet<T> {

    /**
     *
     * @param val is the value to be
     *            added to the set
     * @pre
     * MIN_VALUE < val < MAX_VALUE
     * @post
     * 0 <= ISet.getSize() < MAX_SIZE
     */
    void add(T val);

    /**
     *
     * @param pos is a position in the set
     * @return the value removed
     * @pre
     * 0 <= pos < ISet.getSize() && getSize() != 0
     * @post
     * ISet.getSize() >= 0
     */
    T removePos(int pos);

    /**
     *
     * @param val, a value supposedly in set
     * @return returns true if int val is
     *         present in the set
     * @pre
     * val is a valid input int or double
     * @post
     * true or false will be returned
     */
    boolean contains(T val);

    /**
     *
     * @return returns the size of the set
     * @pre
     * ISet list or array exists
     * @post
     * 0 <= return <= 100
     */
    int getSize();

    /**
     * @pre unionWith.size() != 0
     * @post unionWith.size >= 1
     */
    default void union(ISet<T> unionWith){

        for(int i = 0; i < unionWith.getSize(); i++ ){
            T temp = unionWith.removePos(0);
            if(!this.contains(temp)){
                this.add(temp);
            }
        }

    }

    /**
     * @pre intWith.size() != 0
     * @post unionWith.size >= 1
     */
    default void intersect(ISet<T> intWith){

        for(int i = 0; i < intWith.getSize(); i++){
            T temp = intWith.removePos(0);
            if(this.contains(temp) && intWith.contains(temp)){
                this.add(temp);
            }
        }

    }

    /**
     * @pre diffWith.size() >= 0
     * @post diffWith.size() >= 1
     */
    default void difference(ISet<T> diffWith){

        /* temp list contains values inside 'this', but not in diffWith.
           get the values, then delete from this then add all elements of
           temp list to this.
         */
        //ISet result = (ISet) new ArraySet();
        List<T> result = new ArrayList<>();

        for(int i = 0; i <= diffWith.getSize(); i++ ){
            T tempValue = diffWith.removePos(0);

            if(!this.contains(tempValue)){
                result.add(tempValue);
            }
        }

        //Removing all values in this
        for(int i = 0; i <= this.getSize(); i++ ){
            this.removePos(0);
        }

        for(int i = 0; i <= result.size(); i++ ){
            T element = result.get(i);
            this.add(element);
        }
    }

}

