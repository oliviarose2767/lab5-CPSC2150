/*
    Olivia Papotto
    Phillip Do
 */
package cpsc2150.lab5;

/**
 *
 * @invariant arr.getSize() >= 0
 */
public class ArraySet<T> extends SetAbs<T> implements ISet<T>{

    private static int MAX_SIZE = 100;
    private Object[] arr;

    /**
     * @post ArraySet()
     */
    public ArraySet(){
        arr = new Object[MAX_SIZE];
    }

    public void add(Object val) {

        if(val instanceof Integer){

            for(int i = 0; i < arr.length; i++){
                if(arr[i] == null){
                    arr[i] = (Integer)val;
                    break;
                }
            }

        }else if(val instanceof Double) {
            for (int i = 0; i < arr.length; i++) {
                if (arr[i] == null) {
                    arr[i] = (Double) val;
                    break;
                }
            }
        }

    }

    public T removePos(int pos) {

        T removed = (T)arr[pos];

        for(int i = pos; i < arr.length - 1; i++){
            arr[i] = arr[i + 1];
        }

        return removed;

    }

    public boolean contains(T val) {

        boolean contains = false;

        for(int i = 0; i < arr.length; i++){
            if(arr[i] == val){
                contains = true;
            }
        }

        return contains;

    }

    public int getSize() {

        return arr.length;

    }

    public boolean isEmpty(){

        boolean empty = true;

        for(int i = 0; i < MAX_SIZE; i++){
            if(arr[i] != null){
                empty = false;
            }
        }

        return empty;

    }

}
