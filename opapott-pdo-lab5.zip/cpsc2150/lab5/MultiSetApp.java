/*
    Olivia Papotto
    Phillip Do
 */
package cpsc2150.lab5;

import java.util.*;

public class MultiSetApp {

    public static void main(String[] args) {

        ISet<Integer> arr1 = new ArraySet();
        ArraySet arr2 = new ArraySet();
        ListSet list1 = new ListSet();
        ListSet list2 = new ListSet();

        final int array = 1;
        final int list = 2;
        final int union = 1;
        final int intersection = 2;
        final int difference = 3;
        final int equal = 4;
        final int exit = 5;

        //get option to find Union, Intersection, or Difference.
        Integer option;

        do {
            printMenu();
            Scanner scanner = new Scanner(System.in);
            option = Integer.parseInt(scanner.nextLine());

            if (option == union) {
                System.out.println("Make set 1");
                Integer choice1 = getChoice();
                if (choice1 == array) {
                    arr1 = getArray();
                } else {
                    list1 = getList();
                }
                System.out.println("Make set 2");
                Integer choice2 = getChoice();
                if (choice2 == array) {
                    arr2 = getArray();
                } else {
                    list2 = getList();
                }

                //two arrays
                if (choice1 == array && choice2 == array) {
                    System.out.println("Set 1 is: ");
                    System.out.println(arr1.toString());
                    System.out.println("Set 2 is: ");
                    System.out.println(arr2.toString());
                    arr1.union(arr2);
                    System.out.println("The union is:");
                    System.out.println(arr1.toString() + '\n');
                }
                //two lists
                if (choice1 == list && choice2 == list) {
                    System.out.println("Set 1 is: ");
                    System.out.println(list1.toString());
                    System.out.println("Set 2 is: ");
                    System.out.println(list2.toString());
                    list1.union(list2);
                    System.out.println("The union is:");
                    System.out.println(list1.toString() + '\n');
                }
                //first array second list
                if (choice1 == array && choice2 == list) {
                    System.out.println("Set 1 is: ");
                    System.out.println(arr1.toString());
                    System.out.println("Set 2 is: ");
                    System.out.println(list2.toString());
                    arr1.union(list2);
                    System.out.println("The union is:");
                    System.out.println(arr1.toString() + '\n');
                }
                //first list second array
                if (choice1 == list && choice2 == array) {
                    System.out.println("Set 1 is: ");
                    System.out.println(list1.toString());
                    System.out.println("Set 2 is: ");
                    System.out.println(arr2.toString());
                    list1.union(arr2);
                    System.out.println("The union is:");
                    System.out.println(list1.toString() + '\n');
                }
            } else if (option == intersection) {
                System.out.println("Make set 1");
                Integer choice1 = getChoice();
                if (choice1 == array) {
                    arr1 = getArray();
                } else {
                    list1 = getList();
                }
                System.out.println("Make set 2");
                Integer choice2 = getChoice();
                if (choice2 == array) {
                    arr2 = getArray();
                } else {
                    list2 = getList();
                }

                //two arrays
                if (choice1 == array && choice2 == array) {
                    System.out.println("Set 1 is: ");
                    System.out.println(arr1.toString());
                    System.out.println("Set 2 is: ");
                    System.out.println(arr2.toString());
                    arr1.intersect(arr2);
                    System.out.println("The intersection is:");
                    System.out.println(arr1.toString() + '\n');
                }
                //two lists
                if (choice1 == list && choice2 == list) {
                    System.out.println("Set 1 is: ");
                    System.out.println(list1.toString());
                    System.out.println("Set 2 is: ");
                    System.out.println(list2.toString());
                    list1.intersect(list2);
                    System.out.println("The intersection is:");
                    System.out.println(list1.toString() + '\n');
                }
                //first array second list
                if (choice1 == array && choice2 == list) {
                    System.out.println("Set 1 is: ");
                    System.out.println(arr1.toString());
                    System.out.println("Set 2 is: ");
                    System.out.println(list2.toString());
                    arr1.intersect(list2);
                    System.out.println("The intersection is:");
                    System.out.println(arr1.toString() + '\n');
                }
                //first list second array
                if (choice1 == list && choice2 == array) {
                    System.out.println("Set 1 is: ");
                    System.out.println(list1.toString());
                    System.out.println("Set 2 is: ");
                    System.out.println(arr2.toString());
                    list1.intersect(arr2);
                    System.out.println("The intersection is:");
                    System.out.println(list1.toString() + '\n');
                }
            } else if (option == difference) {
                System.out.println("Make set 1");
                Integer choice1 = getChoice();
                if (choice1 == array) {
                    arr1 = getArray();
                } else {
                    list1 = getList();
                }

                System.out.println("Make set 2");
                Integer choice2 = getChoice();
                if (choice2 == array) {
                    arr2 = getArray();
                } else {
                    list2 = getList();
                }

                //two arrays
                if (choice1 == array && choice2 == array) {
                    System.out.println("Set 1 is: ");
                    System.out.println(arr1.toString());
                    System.out.println("Set 2 is: ");
                    System.out.println(arr2.toString());
                    arr1.difference(arr2);
                    System.out.println("The difference is:");
                    System.out.println(arr1.toString() + '\n');
                }
                //two lists
                if (choice1 == list && choice2 == list) {
                    System.out.println("Set 1 is: ");
                    System.out.println(list1.toString());
                    System.out.println("Set 2 is: ");
                    System.out.println(list2.toString());
                    list1.difference(list2);
                    System.out.println("The difference is:");
                    System.out.println(list1.toString() + '\n');
                }
                //first array second list
                if (choice1 == array && choice2 == list) {
                    System.out.println("Set 1 is: ");
                    System.out.println(arr1.toString());
                    System.out.println("Set 2 is: ");
                    System.out.println(list2.toString());
                    arr1.difference(list2);
                    System.out.println("The difference is:");
                    System.out.println(arr1.toString() + '\n');
                }
                //first list second array
                if (choice1 == list && choice2 == array) {
                    System.out.println("Set 1 is: ");
                    System.out.println(list1.toString());
                    System.out.println("Set 2 is: ");
                    System.out.println(arr2.toString());
                    list1.difference(arr2);
                    System.out.println("The difference is:");
                    System.out.println(list1.toString() + '\n');
                }
            } else if (option == equal){
                System.out.println("Make set 1");
                Integer choice1 = getChoice();
                if (choice1 == array) {
                    arr1 = getArray();
                } else {
                    list1 = getList();
                }

                System.out.println("Make set 2");
                Integer choice2 = getChoice();
                if (choice2 == array) {
                    arr2 = getArray();
                } else {
                    list2 = getList();
                }

                //two arrays
                if (choice1 == array && choice2 == array) {
                    System.out.println("Set 1 is: ");
                    System.out.println(arr1.toString());
                    System.out.println("Set 2 is: ");
                    System.out.println(arr2.toString());
                    if(arr1.equals(arr2)){
                        System.out.println("The sets are equal!");
                    }else{
                        System.out.println("The sets are not equal!");
                    }
                }
                //two lists
                if (choice1 == list && choice2 == list) {
                    System.out.println("Set 1 is: ");
                    System.out.println(list1.toString());
                    System.out.println("Set 2 is: ");
                    System.out.println(list2.toString());
                    if(list1.equals(list2)){
                        System.out.println("The sets are equal!");
                    }else{
                        System.out.println("The sets are not equal!");
                    }
                }
                //first array second list
                if (choice1 == array && choice2 == list) {
                    System.out.println("Set 1 is: ");
                    System.out.println(arr1.toString());
                    System.out.println("Set 2 is: ");
                    System.out.println(list2.toString());
                    if(arr1.equals(list2)){
                        System.out.println("The sets are equal!");
                    }else{
                        System.out.println("The sets are not equal!");
                    }
                }
                //first list second array
                if (choice1 == list && choice2 == array) {
                    System.out.println("Set 1 is: ");
                    System.out.println(list1.toString());
                    System.out.println("Set 2 is: ");
                    System.out.println(arr2.toString());
                    if(list1.equals(arr2)){
                        System.out.println("The sets are equal!");
                    }else{
                        System.out.println("The sets are not equal!");
                    }
                }
            }

        } while (option != exit);

    }

    /*
     * prints the menu option for the user
     */
    private static void printMenu(){
        System.out.println(" Make a selection");
        System.out.println("1. Find the Union of Two Sets");
        System.out.println("2. Find the Intersection of Two Sets");
        System.out.println("3. Find the Difference of Two sets");
        System.out.println("4. See if two sets are equal");
        System.out.println("5. Exit");
    }

    /**
     *
     * @param obj is an object of user choice that will
     *            have elements added to
     * @param val a value to be added to the array
     */
    private static void addArray(ArraySet obj, Object val){
        if(!obj.contains(val)){
            obj.add(val);
            //System.out.println(obj.toString());
        }else{
            System.out.println("That value is already in the set.");
            //System.out.println(obj.toString());
        }
    }

    /**
     *
     * @param obj an object of user choice, that will
     *            have elements added to it
     * @param val a value to be added to list
     */
    private static void addList(ListSet obj, Integer val){
        //check if val is already in set
        if(!obj.contains(val)){
            obj.add(val);
            //System.out.println(obj.toString());
        }else{
            System.out.println("That value is already in the set.");
            //System.out.println(obj.toString());
        }
    }

    /**
     * @return the user choice of implementation (1 or 2)
     */
    private static Integer getChoice(){

        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter 1 for array implementation or 2 for a list implementation");

        Integer input = Integer.parseInt(scanner.nextLine());

        if(input != 1 && input != 2){
            System.out.println("Invalid! Must be 1 or 2. Try again!");
            input = Integer.parseInt(scanner.nextLine());
        }

        return input;
    }

    /**
     * Reads user input into ArraySet
     *
     * @return ArraySet that contains user input
     */
    private static ArraySet getArray(){
        Scanner scanner = new Scanner(System.in);
        ArraySet temp = new ArraySet();
        String choice = new String();

        while(choice != "q"){
            System.out.println("Enter a value to add to the set. Enter q to stop adding to the set");
            choice = scanner.nextLine();

            if(choice == "q"){break;}
            else{
                try{
                    Integer num = Integer.parseInt(choice);
                    addArray(temp,num);
                }
                catch (NumberFormatException e){break;}
            }
        }

        return temp;
    }

    /**
     * Reads user input into ListSet
     *
     * @returns a ListSet containing user elements
     */
    private static ListSet getList(){
        Scanner scanner = new Scanner(System.in);
        ListSet temp = new ListSet();
        String choice = new String();

        while(choice != "q"){
            System.out.println("Enter a value to add to the set. Enter q to stop adding to the set");
            choice = scanner.nextLine();

            if(choice == "q"){break;}
            else{
                try{
                    Integer num = Integer.parseInt(choice);
                    addList(temp,num);
                }
                catch (NumberFormatException e){break;}
            }
        }

        return temp;
    }

}
